/* =====================================================================
   3D INK DRAGON for the site background (loaded by bg3d.js)
   A long serpentine dragon built entirely in code: black ink skin, pale belly
   scales, mane, horns, whiskers, clawed legs, feathered tail, pale blue eye.
   It flies along a closed loop in front of the camera. Scrolling moves it
   along the loop, the mouse pulls its head. To remove the dragon, delete this
   file; the rest of the background keeps working.
   ===================================================================== */
window.createDragon = function (THREE, camera, opts) {
  'use strict';
  const V = THREE.Vector3;
  const RINGS = opts.low ? 90 : 170, SIDES = opts.low ? 10 : 14, BLADES = opts.low ? 170 : 460;
  const DEPTH = 26;          // distance in front of the camera (nearer than the planet, so it passes in front)
  const BODY_RADIUS = 1.6;

  /* ---------- materials ---------- */
  const sunView = new V();
  // Which layer is drawing: 0 = behind the page content, 1 = above it, 2 = everything (no upper layer available).
  const passU = { value: 2 };
  const WEAVE = 2;           // how many times per lap the dragon dives over and under the page
  const inkVert = `
    varying vec3 vN, vV; varying vec2 vUv; varying float vM;
    #ifdef ATTR_M
      attribute float aM;
    #else
      uniform float uM;
    #endif
    void main(){
      #ifdef ATTR_M
        vM = aM;
      #else
        vM = uM;
      #endif
      vec3 p = position, n = normal;
      #ifdef USE_INSTANCING
        p = (instanceMatrix * vec4(p, 1.0)).xyz;
        n = mat3(instanceMatrix) * n;
      #endif
      vec4 mv = modelViewMatrix * vec4(p, 1.0);
      vN = normalMatrix * n; vV = -mv.xyz; vUv = uv;
      gl_Position = projectionMatrix * mv;
    }`;
  const inkFrag = `
    uniform vec3 uSun; uniform float uScales, uRim, uPass;
    varying vec3 vN, vV; varying vec2 vUv; varying float vM;
    void main(){
      // Grainy, ink-like dissolve where the dragon passes through the page.
      float keep = uPass > 1.5 ? 1.0 : (uPass > 0.5 ? vM : 1.0 - vM);
      if (keep <= fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453)) discard;
      vec3 n = normalize(vN), v = normalize(vV);
      float ndl = dot(n, uSun);
      float rim = pow(1.0 - max(dot(n, v), 0.0), 3.0);
      vec3 col = vec3(0.012, 0.012, 0.016);
      col += vec3(0.055, 0.052, 0.05) * max(ndl, 0.0);
      col += mix(vec3(0.30, 0.38, 0.46), vec3(0.95, 0.74, 0.50), smoothstep(-0.3, 0.6, ndl)) * rim * uRim;
      vec3 h = normalize(uSun + v);
      col += vec3(1.0, 0.92, 0.82) * pow(max(dot(n, h), 0.0), 48.0) * 0.08 * uRim;
      if (uScales > 0.5) {
        float u = vUv.x * 96.0, row = floor(u);
        float th = vUv.y * 12.0 + mod(row, 2.0) * 0.5;
        vec2 cell = vec2(fract(u), fract(th));
        float arc = smoothstep(0.05, 0.0, abs(length(cell - vec2(0.0, 0.5)) - 0.6));
        float belly = smoothstep(-0.1, -0.6, cos(vUv.y * 6.2831853));
        col += vec3(0.70, 0.67, 0.58) * arc * (belly * 0.8 + 0.012) * (max(ndl, 0.0) * 0.7 + 0.3);
      }
      // The upper layer has no dark overlay on it, so darken it to match the lower layer.
      if (uPass > 0.5 && uPass < 1.5) col *= 0.5;
      gl_FragColor = vec4(col, 1.0);
    }`;
  const mat = (scales, rim, perVertex) => new THREE.ShaderMaterial({
    vertexShader: inkVert, fragmentShader: inkFrag,
    defines: perVertex ? { ATTR_M: 1 } : {},
    uniforms: { uSun: { value: sunView }, uScales: { value: scales ? 1 : 0 }, uRim: { value: rim }, uPass: passU, uM: { value: 0 } }
  });
  const hair = mat(false, 0.2, true);

  /* ---------- geometry helpers ---------- */
  function taper(points, r0, r1, sides) {
    const rings = points.length, pos = [], nor = [], idx = [];
    const ref = new V(0.31, 0.2, 0.93), a = new V(), b = new V(), t = new V();
    points.forEach((p, i) => {
      t.subVectors(points[Math.min(i + 1, rings - 1)], points[Math.max(i - 1, 0)]).normalize();
      a.crossVectors(t, ref).normalize(); b.crossVectors(t, a).normalize();
      const r = r0 + (r1 - r0) * (i / (rings - 1));
      for (let s = 0; s < sides; s++) {
        const th = s / sides * Math.PI * 2, c = Math.cos(th), d = Math.sin(th);
        const nx = a.x * c + b.x * d, ny = a.y * c + b.y * d, nz = a.z * c + b.z * d;
        pos.push(p.x + nx * r, p.y + ny * r, p.z + nz * r); nor.push(nx, ny, nz);
      }
    });
    for (let i = 0; i < rings - 1; i++) for (let s = 0; s < sides; s++) {
      const n = (s + 1) % sides, A = i * sides + s, B = i * sides + n, C = (i + 1) * sides + s, D = (i + 1) * sides + n;
      idx.push(A, C, B, B, C, D);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
    g.setIndex(idx);
    return g;
  }
  function blob(x, y, z, sx, sy, sz, rx) {
    const g = new THREE.SphereBufferGeometry(1, 16, 12);
    const m = new THREE.Matrix4().compose(new V(x, y, z), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx || 0, 0, 0)), new V(sx, sy, sz));
    g.applyMatrix4(m);
    return g;
  }
  function merge(list) {
    const pos = [], nor = [], idx = []; let off = 0;
    list.forEach(g => {
      const p = g.attributes.position, n = g.attributes.normal, ix = g.index;
      for (let i = 0; i < p.count; i++) { pos.push(p.getX(i), p.getY(i), p.getZ(i)); nor.push(n.getX(i), n.getY(i), n.getZ(i)); }
      for (let i = 0; i < ix.count; i++) idx.push(ix.getX(i) + off);
      off += p.count; g.dispose();
    });
    const out = new THREE.BufferGeometry();
    out.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    out.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
    out.setIndex(idx);
    return out;
  }
  const pts = (...a) => a.map(p => new V(p[0], p[1], p[2]));

  const group = new THREE.Group();
  camera.add(group);

  /* ---------- body: rebuilt along the spine every frame ---------- */
  const vCount = (RINGS + 1) * SIDES;
  const bodyPos = new Float32Array(vCount * 3), bodyNor = new Float32Array(vCount * 3), bodyUv = new Float32Array(vCount * 2);
  const bodyIdx = [];
  for (let i = 0; i < RINGS; i++) for (let s = 0; s < SIDES; s++) {
    const n = (s + 1) % SIDES, A = i * SIDES + s, B = i * SIDES + n, C = (i + 1) * SIDES + s, D = (i + 1) * SIDES + n;
    bodyIdx.push(A, B, C, B, D, C);
  }
  for (let i = 0; i <= RINGS; i++) for (let s = 0; s < SIDES; s++) {
    const k = (i * SIDES + s) * 2; bodyUv[k] = i / RINGS; bodyUv[k + 1] = s / SIDES;
  }
  const bodyGeo = new THREE.BufferGeometry();
  bodyGeo.setAttribute('position', new THREE.BufferAttribute(bodyPos, 3).setUsage(THREE.DynamicDrawUsage));
  bodyGeo.setAttribute('normal', new THREE.BufferAttribute(bodyNor, 3).setUsage(THREE.DynamicDrawUsage));
  bodyGeo.setAttribute('uv', new THREE.BufferAttribute(bodyUv, 2));
  bodyGeo.setIndex(bodyIdx);
  const bodyMask = new Float32Array(vCount);
  bodyGeo.setAttribute('aM', new THREE.BufferAttribute(bodyMask, 1).setUsage(THREE.DynamicDrawUsage));
  const body = new THREE.Mesh(bodyGeo, mat(true, 0.5, true));
  body.frustumCulled = false;
  group.add(body);

  /* ---------- head (forward = +Z, up = +Y) ---------- */
  const headGeo = merge([
    blob(0, 0.05, 0.2, 1.05, 0.86, 1.5),                 // skull
    blob(0, -0.12, 1.75, 0.62, 0.46, 1.4),               // snout
    blob(0.3, 0.14, 3.0, 0.2, 0.17, 0.26), blob(-0.3, 0.14, 3.0, 0.2, 0.17, 0.26),   // nostrils
    blob(0, -0.66, 1.3, 0.54, 0.2, 1.3, 0.2),            // lower jaw
    blob(0.56, 0.42, 0.95, 0.34, 0.2, 0.62, -0.3), blob(-0.56, 0.42, 0.95, 0.34, 0.2, 0.62, -0.3),   // brows
    taper(pts([0.42, 0.6, -0.1], [0.72, 1.4, -1.1], [0.84, 2.0, -2.3], [1.12, 2.5, -3.5]), 0.17, 0.02, 6),   // horns
    taper(pts([-0.42, 0.6, -0.1], [-0.72, 1.4, -1.1], [-0.84, 2.0, -2.3], [-1.12, 2.5, -3.5]), 0.17, 0.02, 6),
    taper(pts([0.74, 1.55, -1.3], [1.2, 2.0, -1.5], [1.5, 2.6, -1.75]), 0.08, 0.015, 5),                       // antler branches
    taper(pts([-0.74, 1.55, -1.3], [-1.2, 2.0, -1.5], [-1.5, 2.6, -1.75]), 0.08, 0.015, 5),
    taper(pts([0.4, 0.05, 3.05], [1.0, -0.2, 3.9], [1.9, -0.9, 4.2], [3.1, -1.9, 3.5], [4.1, -3.1, 2.4]), 0.045, 0.008, 4),      // whiskers
    taper(pts([-0.4, 0.05, 3.05], [-1.0, -0.2, 3.9], [-1.9, -0.9, 4.2], [-3.1, -1.9, 3.5], [-4.1, -3.1, 2.4]), 0.045, 0.008, 4)
  ]);
  const head = new THREE.Mesh(headGeo, mat(false, 1.0));
  head.frustumCulled = false;
  const headBits = [];
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xbfe6f2 });
  const pupilMat = new THREE.MeshBasicMaterial({ color: 0x050507 });
  [1, -1].forEach(side => {
    const eye = new THREE.Mesh(new THREE.SphereBufferGeometry(0.2, 12, 10), eyeMat);
    eye.position.set(side * 0.74, 0.24, 1.0);
    const pupil = new THREE.Mesh(new THREE.SphereBufferGeometry(0.1, 10, 8), pupilMat);
    pupil.position.set(side * 0.87, 0.25, 1.06); pupil.scale.set(0.8, 1.3, 0.6);
    head.add(eye, pupil); headBits.push(eye, pupil);
  });
  const teeth = [];
  for (let i = 0; i < 6; i++) {
    const side = i % 2 ? 1 : -1, z = 2.3 - Math.floor(i / 2) * 0.55;
    const g = new THREE.ConeBufferGeometry(0.06, 0.3, 5);
    g.rotateX(Math.PI); g.translate(side * 0.42, -0.45, z);
    teeth.push(g);
  }
  const teethMesh = new THREE.Mesh(merge(teeth), new THREE.MeshBasicMaterial({ color: 0xd9d6c8 }));
  head.add(teethMesh); headBits.push(teethMesh);
  group.add(head);

  /* ---------- legs with claws (local +Y runs out along the limb) ---------- */
  const claw = (x, z) => taper(pts([x * 0.4, 3.75, z * 0.4], [x, 4.3, z], [x * 1.25, 4.75, z * 1.35], [x * 1.3, 5.0, z * 1.9]), 0.1, 0.012, 5);
  const limbGeo = merge([
    taper(pts([0, 0, 0], [0, 1.1, 0.3], [0, 2.1, 0.1], [0, 3.1, 0.3], [0, 3.8, 0.25]), 0.5, 0.2, 7),
    blob(0, 3.8, 0.25, 0.36, 0.26, 0.42),
    claw(0.34, 0.5), claw(-0.34, 0.5), claw(0.0, 0.7), claw(0.5, -0.1)
  ]);
  const limbs = [[0.19, 1], [0.21, -1], [0.63, 1], [0.65, -1]].map(l => {
    const m = new THREE.Mesh(limbGeo, mat(false, 1.0));
    m.matrixAutoUpdate = false; m.frustumCulled = false;
    group.add(m);
    return { u: l[0], side: l[1], mesh: m, phase: Math.random() * 6 };
  });

  /* ---------- mane, dorsal fringe, leg tufts and tail plume ---------- */
  const bladeGeo = taper(pts([0, 0, 0], [0, 0.38, -0.04], [0, 0.72, -0.15], [0, 1, -0.34]), 0.05, 0.002, 4);
  const bladeMesh = new THREE.InstancedMesh(bladeGeo, hair, BLADES);
  bladeMesh.frustumCulled = false;
  bladeMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  const bladeMask = new THREE.InstancedBufferAttribute(new Float32Array(BLADES), 1).setUsage(THREE.DynamicDrawUsage);
  bladeGeo.setAttribute('aM', bladeMask);
  group.add(bladeMesh);
  const rnd = (a, b) => a + Math.random() * (b - a);
  const blades = [];
  for (let i = 0; i < BLADES; i++) {
    const f = i / BLADES;
    if (f < 0.42) blades.push({ u: rnd(0.04, 0.95), a: rnd(-0.55, 0.55), len: rnd(1.3, 3.0), lean: rnd(0.45, 0.95) });                // along the back
    else if (f < 0.68) blades.push({ u: rnd(0.012, 0.2), a: rnd(-1.3, 1.3), len: rnd(2.2, 4.8), lean: rnd(0.5, 1.05) });               // neck mane
    else if (f < 0.8) { const rear = Math.random() < 0.5, c = rear ? 0.64 : 0.2;
      blades.push({ u: c + rnd(-0.035, 0.035), a: (Math.random() < 0.5 ? 1 : -1) * rnd(1.4, 2.4), len: rnd(1.4, 2.8), lean: rnd(0.8, 1.25) }); }   // leg tufts
    else blades.push({ u: rnd(0.93, 1), a: rnd(-3.14, 3.14), len: rnd(2.6, 6.2), lean: rnd(1.0, 1.4) });                            // tail plume
    blades[i].w = rnd(0.09, 0.17); blades[i].phase = Math.random() * 6.28;
  }

  /* ---------- flight loop: closed curve, sampled evenly by distance ---------- */
  const TABLE = 1024;
  const table = new Float32Array((TABLE + 1) * 3);
  let total = 100, bodyLen = 55, k = 1;
  function layout() {
    const hh = Math.tan(camera.fov * Math.PI / 360) * DEPTH, hw = hh * camera.aspect;
    const A = hw * 0.74, B = hh * 0.62;
    const raw = [], n = 2400;
    let len = 0, prev = null;
    for (let i = 0; i <= n; i++) {
      const a = i / n * Math.PI * 2;
      const p = new V(A * Math.sin(a) + A * 0.22 * Math.sin(3 * a), B * Math.sin(2 * a + 0.6), -DEPTH + 4 * Math.cos(a));
      if (prev) len += p.distanceTo(prev);
      raw.push({ p, len }); prev = p;
    }
    total = len;
    for (let i = 0, j = 0; i <= TABLE; i++) {
      const want = i / TABLE * total;
      while (j < n && raw[j + 1].len < want) j++;
      const r0 = raw[j], r1 = raw[Math.min(j + 1, n)], f = r1.len > r0.len ? (want - r0.len) / (r1.len - r0.len) : 0;
      table[i * 3] = r0.p.x + (r1.p.x - r0.p.x) * f;
      table[i * 3 + 1] = r0.p.y + (r1.p.y - r0.p.y) * f;
      table[i * 3 + 2] = r0.p.z + (r1.p.z - r0.p.z) * f;
    }
    bodyLen = Math.min(total * 0.4, 58);
    k = Math.max(0.55, Math.min(1, bodyLen / 56));
  }
  function samplePath(s, out) {
    const f = (((s / total) % 1) + 1) % 1 * TABLE, i = Math.floor(f), g = f - i, a = i * 3, b = (i + 1) * 3;
    return out.set(table[a] + (table[b] - table[a]) * g, table[a + 1] + (table[b + 1] - table[a + 1]) * g, table[a + 2] + (table[b + 2] - table[a + 2]) * g);
  }

  // 1 = above the page, 0 = behind it. Tied to the path, so every part of the body
  // dives through the page at the same spots, like a needle and thread.
  const frontAt = s => { const v = Math.sin(s / total * Math.PI * 2 * WEAVE); const x = Math.min(Math.max((v + 0.1) / 0.2, 0), 1); return x * x * (3 - 2 * x); };

  /* ---------- per-frame pose ---------- */
  let headMask = 0;
  const P = [], T = [], D = [], R = [];
  for (let i = 0; i <= RINGS; i++) { P.push(new V()); T.push(new V()); D.push(new V()); R.push(new V()); }
  const UP = new V(0, 0.92, 0.4).normalize();    // mostly side-on: black back above, pale belly scales along the lower edge
  const radius = u => BODY_RADIUS * k * (0.56 + 0.44 * Math.min(u / 0.14, 1)) * Math.pow(Math.max(1 - u, 0), 0.62) + 0.015;
  const tmp = new V(), dir = new V(), bY = new V(), bZ = new V(), bX = new V(), m4 = new THREE.Matrix4();

  function update(t, travel, mx, my, flap, sun) {
    sunView.copy(sun).transformDirection(camera.matrixWorldInverse);
    const headS = total * 0.09 + travel + t * 1.1 * k;
    const amp = (2.5 + flap * 1.8) * k;
    const phase = t * 2.1 + travel * 0.16;

    for (let i = 0; i <= RINGS; i++) {
      const u = i / RINGS, env = 0.25 + u * 0.95;
      samplePath(headS - u * bodyLen, P[i]);
      P[i].y += Math.sin(u * 10.5 - phase) * amp * env;
      P[i].x += Math.cos(u * 7.5 - phase * 0.9) * amp * 0.7 * env;
      P[i].z += Math.cos(u * 6.5 - phase * 0.8) * amp * 0.8 * env;
      const pull = Math.pow(1 - u, 1.7);          // the mouse draws the head, the body follows
      P[i].x += mx * 5.5 * k * pull;
      P[i].y += my * 3.4 * k * pull;
    }
    for (let i = 0; i <= RINGS; i++) {
      T[i].subVectors(P[Math.max(i - 1, 0)], P[Math.min(i + 1, RINGS)]).normalize();   // points towards the head
      if (i === 0) D[0].copy(UP).addScaledVector(T[0], -UP.dot(T[0])).normalize();
      else D[i].copy(D[i - 1]).addScaledVector(T[i], -D[i - 1].dot(T[i])).normalize();
      R[i].crossVectors(T[i], D[i]).normalize();
    }

    // body surface
    for (let i = 0; i <= RINGS; i++) {
      const r = radius(i / RINGS), mask = frontAt(headS - i / RINGS * bodyLen);
      bodyMask.fill(mask, i * SIDES, (i + 1) * SIDES);
      for (let s = 0; s < SIDES; s++) {
        const th = s / SIDES * Math.PI * 2, c = Math.cos(th), d = Math.sin(th), w = (i * SIDES + s) * 3;
        const nx = D[i].x * c + R[i].x * d, ny = D[i].y * c + R[i].y * d, nz = D[i].z * c + R[i].z * d;
        bodyPos[w] = P[i].x + nx * r; bodyPos[w + 1] = P[i].y + ny * r; bodyPos[w + 2] = P[i].z + nz * r;
        bodyNor[w] = nx; bodyNor[w + 1] = ny; bodyNor[w + 2] = nz;
      }
    }
    bodyGeo.attributes.position.needsUpdate = true;
    bodyGeo.attributes.normal.needsUpdate = true;
    bodyGeo.attributes.aM.needsUpdate = true;
    head.material.uniforms.uM.value = headMask = frontAt(headS);

    // head: follows the front of the spine
    bY.set(0, 1, 0.12).addScaledVector(T[0], -(T[0].y + 0.12 * T[0].z)).normalize();
    tmp.crossVectors(bY, T[0]).normalize();
    head.matrixAutoUpdate = false;
    m4.makeBasis(tmp, bY, T[0]).scale(tmp.set(k * 1.5, k * 1.5, k * 1.5)).setPosition(P[0]);
    head.matrix.copy(m4);

    // legs: reach out and down, paddling gently
    limbs.forEach(l => {
      const i = Math.round(l.u * RINGS), swing = Math.sin(t * 1.9 + l.phase) * (0.28 + flap * 0.4);
      dir.copy(R[i]).multiplyScalar(l.side * 0.72).addScaledVector(D[i], -0.62).addScaledVector(T[i], -0.2 + swing).normalize();
      bZ.copy(T[i]).addScaledVector(dir, -T[i].dot(dir)).normalize();
      bX.crossVectors(dir, bZ).normalize();
      const s = k * 0.86;
      l.mesh.material.uniforms.uM.value = frontAt(headS - l.u * bodyLen);
      l.mesh.matrix.makeBasis(bX, dir, bZ).scale(tmp.set(s, s, s)).setPosition(P[i]);
    });

    // mane and plume: every blade flutters with the flight
    const e = bladeMesh.instanceMatrix.array;
    for (let n = 0; n < BLADES; n++) {
      const b = blades[n], i = Math.min(Math.round(b.u * RINGS), RINGS), r = radius(b.u);
      const c = Math.cos(b.a), d = Math.sin(b.a);
      dir.copy(D[i]).multiplyScalar(c).addScaledVector(R[i], d);
      const lean = b.lean + Math.sin(t * 4.4 + b.phase + b.u * 9) * (0.13 + flap * 0.22);
      bY.copy(dir).multiplyScalar(Math.cos(lean)).addScaledVector(T[i], -Math.sin(lean)).normalize();
      bZ.copy(T[i]).addScaledVector(bY, -T[i].dot(bY)).normalize();
      bX.crossVectors(bY, bZ).normalize();
      const len = b.len * k * (0.45 + 0.55 * Math.min(r / (BODY_RADIUS * k * 0.5), 1) + (b.u > 0.92 ? 0.4 : 0)), wid = len * (b.w / 0.12), o = n * 16;
      e[o] = bX.x * wid; e[o + 1] = bX.y * wid; e[o + 2] = bX.z * wid; e[o + 3] = 0;
      e[o + 4] = bY.x * len; e[o + 5] = bY.y * len; e[o + 6] = bY.z * len; e[o + 7] = 0;
      e[o + 8] = bZ.x * len; e[o + 9] = bZ.y * len; e[o + 10] = bZ.z * len; e[o + 11] = 0;
      bladeMask.array[n] = frontAt(headS - b.u * bodyLen);
      e[o + 12] = P[i].x + dir.x * r * 0.8; e[o + 13] = P[i].y + dir.y * r * 0.8; e[o + 14] = P[i].z + dir.z * r * 0.8; e[o + 15] = 1;
    }
    bladeMesh.instanceMatrix.needsUpdate = true;
    bladeMask.needsUpdate = true;
  }

  // Every dragon mesh sits on layer 1, so the upper canvas can draw only the dragon.
  group.traverse(o => o.layers.set(1));
  function setPass(pass) {
    passU.value = pass;
    const showBits = pass === 2 || (headMask > 0.5) === (pass === 1);
    headBits.forEach(b => { b.visible = showBits; });
  }

  layout();
  return { update, layout, setPass, get loopLength() { return total; } };
};
