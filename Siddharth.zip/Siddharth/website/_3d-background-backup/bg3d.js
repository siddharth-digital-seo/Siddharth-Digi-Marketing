/* =====================================================================
   SITE BACKGROUND — realistic 3D space scene (Three.js + GSAP)
   Used by every page. Draws into <canvas id="stars">.

   Scene: procedural nebula sky, layered twinkling stars, a rotating spiral
   galaxy, an Earth-like planet with clouds, city lights and atmosphere, and
   occasional shooting stars. Scrolling flies the camera through the scene;
   the mouse adds gentle parallax.

   QUICK SETTINGS are just below. If WebGL or the CDN is unavailable the page
   simply keeps a dark gradient background.
   ===================================================================== */
(function(){
  'use strict';

  /* ---------- QUICK SETTINGS ---------- */
  const SCRIM_CENTER = 0.42;    // darkening over the scene, centre of screen (0–1) — raise if text is hard to read
  const SCRIM_EDGE   = 0.62;    // darkening at the screen edges
  const SHOOTING_STARS = true;
  const THREE_URL = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
  const GSAP_URL  = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js';
  const ST_URL    = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js';
  const DRAGON_LAPS = 2.2;      // how many times the dragon circles the screen from top to bottom of a page
  /* ------------------------------------ */

  const DRAGON_URL = ((document.currentScript && document.currentScript.src) || '').replace(/[^/]*$/, '') + 'bg3d-dragon.js';
  const canvas = document.getElementById('stars');
  if (!canvas) return;

  // Dark layer between the scene and the page, keeps text readable.
  const scrim = document.createElement('div');
  scrim.setAttribute('aria-hidden', 'true');
  scrim.style.cssText = 'position:fixed;inset:0;z-index:0;pointer-events:none;background:radial-gradient(ellipse at 50% 42%,rgba(7,7,11,' + SCRIM_CENTER + ') 0%,rgba(7,7,11,' + SCRIM_EDGE + ') 100%);';
  canvas.insertAdjacentElement('afterend', scrim);

  // The footer gets its own dark backing so its links stay readable over the galaxy.
  const footerStyle = document.createElement('style');
  footerStyle.textContent = 'footer{background:rgba(7,7,11,0.84);}';
  document.head.appendChild(footerStyle);

  canvas.style.width = '100%';
  canvas.style.height = (window.CSS && CSS.supports && CSS.supports('height', '100lvh')) ? '100lvh' : '100%';
  canvas.style.opacity = '0';
  canvas.style.pointerEvents = 'none';

  const reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isSmall = Math.min(window.innerWidth, window.innerHeight) < 700;
  const lowEnd = isSmall || (navigator.hardwareConcurrency || 8) <= 4 || (navigator.deviceMemory || 8) <= 4;
  const Q = lowEnd
    ? { galaxy: 22000, stars: 1800, sky: 1024, planet: 1024, seg: 56, dpr: 1.25 }
    : { galaxy: 80000, stars: 5000, sky: 2048, planet: 2048, seg: 96, dpr: 1.75 };

  function load(src){
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src; s.async = false; s.onload = resolve; s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  function start(){
    Promise.all([load(THREE_URL), load(GSAP_URL), load(ST_URL)])
      .then(() => load(DRAGON_URL).catch(() => {}))      // the scene still runs if the dragon file is missing
      .then(() => { try { init(); } catch (e) { fail(e); } })
      .catch(fail);
  }
  function fail(e){
    if (window.console) console.warn('3D background unavailable:', e);
    canvas.style.display = 'none';
  }

  /* ---------- shared GLSL ---------- */
  const NOISE = `
    float hash(vec3 p){ p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
    float noise(vec3 x){
      vec3 i = floor(x), f = fract(x);
      f = f * f * (3.0 - 2.0 * f);
      return mix(mix(mix(hash(i), hash(i + vec3(1,0,0)), f.x), mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
                 mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x), mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y), f.z);
    }
    float fbm(vec3 p, int oct){
      float v = 0.0, a = 0.5;
      const mat3 rot = mat3(0.00, 0.80, 0.60, -0.80, 0.36, -0.48, -0.60, -0.48, 0.64);   // rotate each layer so no grid shows
      for (int i = 0; i < oct; i++){ v += a * noise(p); p = rot * p * 2.03 + vec3(1.7, 9.2, 4.1); a *= 0.5; }
      return v;
    }
    vec3 dirFromUv(vec2 uv){
      float th = uv.x * 6.2831853, ph = uv.y * 3.1415926;
      return vec3(sin(ph) * cos(th), -cos(ph), sin(ph) * sin(th));
    }`;

  const BAKE_VERT = 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }';

  // Dark nebula sky. Stored with a square-root curve so dark gradients don't band.
  const SKY_BAKE = NOISE + `
    varying vec2 vUv;
    void main(){
      vec3 d = dirFromUv(vUv);
      vec3 q = vec3(fbm(d * 2.1, 5), fbm(d * 2.1 + 5.2, 5), fbm(d * 2.1 + 9.3, 5));
      float n  = fbm(d * 2.4 + q * 2.6, 6);
      float n2 = fbm(d * 4.3 - q * 1.8 + 3.0, 6);
      float dust = smoothstep(0.42, 0.74, fbm(d * 3.1 + q.zxy * 2.0 + 7.0, 6));

      vec3 col = vec3(0.012, 0.012, 0.024);
      col += vec3(0.05, 0.08, 0.20) * smoothstep(0.38, 0.72, n);
      col += vec3(0.42, 0.13, 0.035) * pow(smoothstep(0.46, 0.80, n2), 2.0);
      col += vec3(0.05, 0.22, 0.22) * pow(smoothstep(0.50, 0.82, q.y), 2.0);
      col += vec3(0.30, 0.10, 0.22) * pow(smoothstep(0.54, 0.84, q.x), 3.0);
      col *= 1.0 - 0.72 * dust;
      gl_FragColor = vec4(sqrt(clamp(col, 0.0, 1.0)), 1.0);
    }`;

  // Planet surface colour (rgb). Land, ocean, ice.
  const SURFACE_BAKE = NOISE + `
    varying vec2 vUv;
    void main(){
      vec3 d = dirFromUv(vUv);
      vec3 w = vec3(fbm(d * 2.0 + 11.0, 4), fbm(d * 2.0 + 21.0, 4), fbm(d * 2.0 + 31.0, 4));
      float h = fbm(d * 3.0 + w * 1.7, 8);
      float lat = abs(d.y);
      float detail = fbm(d * 22.0, 6);
      vec3 col;
      if (h < 0.5) {
        col = mix(vec3(0.006, 0.030, 0.085), vec3(0.010, 0.075, 0.13), smoothstep(0.34, 0.5, h));
      } else {
        float t = smoothstep(0.5, 0.72, h);
        vec3 forest = mix(vec3(0.022, 0.058, 0.026), vec3(0.075, 0.098, 0.05), detail);
        vec3 desert = mix(vec3(0.20, 0.145, 0.085), vec3(0.34, 0.25, 0.155), detail);
        vec3 rock   = vec3(0.17, 0.14, 0.12);
        float dry = smoothstep(0.42, 0.62, fbm(d * 3.1 + 40.0, 4) + (0.3 - abs(lat - 0.28)) * 0.5);
        col = mix(forest, desert, dry);
        col = mix(col, rock, smoothstep(0.55, 1.0, t));
      }
      float ice = smoothstep(0.80, 0.90, lat + (detail - 0.5) * 0.14);
      col = mix(col, vec3(0.78, 0.82, 0.86), ice);
      gl_FragColor = vec4(sqrt(col), clamp(h, 0.0, 1.0));   // alpha = height, used for relief shading
    }`;

  // r = clouds, g = city lights, b = ocean mask (for sun glint).
  const DATA_BAKE = NOISE + `
    varying vec2 vUv;
    void main(){
      vec3 d = dirFromUv(vUv);
      vec3 w = vec3(fbm(d * 2.0 + 11.0, 4), fbm(d * 2.0 + 21.0, 4), fbm(d * 2.0 + 31.0, 4));
      float h = fbm(d * 3.0 + w * 1.7, 8);
      float lat = abs(d.y);
      vec3 cw = d * vec3(2.6, 6.0, 2.6);
      float c = fbm(cw + 3.0 * fbm(cw * 1.2 + 50.0, 4), 6);
      float clouds = smoothstep(0.53, 0.76, c);
      float land = smoothstep(0.5, 0.52, h);
      float cl = pow(noise(d * 95.0), 7.0) * 9.0 + pow(noise(d * 240.0), 9.0) * 11.0;
      float clusters = smoothstep(0.44, 0.66, fbm(d * 9.0 + 70.0, 4));
      float lights = clamp(cl * clusters * land * (1.0 - smoothstep(0.62, 0.78, lat)), 0.0, 1.0);
      gl_FragColor = vec4(clouds, lights, 1.0 - land, 1.0);
    }`;

  function init(){
    const THREE = window.THREE, gsap = window.gsap;
    gsap.registerPlugin(window.ScrollTrigger);
    gsap.ticker.lagSmoothing(0);   // keep real time on slow devices so fades and the intro always finish

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance', stencil: false });
    let pixelRatio = Math.min(window.devicePixelRatio || 1, Q.dpr);
    renderer.setPixelRatio(pixelRatio);
    renderer.setClearColor(0x05050a, 1);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 4000);
    scene.add(camera);

    /* ---------- bake procedural textures once (cheap to draw afterwards) ---------- */
    function bake(frag, w, h){
      const target = new THREE.WebGLRenderTarget(w, h, { minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: false, stencilBuffer: false });
      target.texture.wrapS = THREE.RepeatWrapping;
      const s = new THREE.Scene(), c = new THREE.Camera();
      const m = new THREE.Mesh(new THREE.PlaneBufferGeometry(2, 2), new THREE.ShaderMaterial({ vertexShader: BAKE_VERT, fragmentShader: frag, depthTest: false, depthWrite: false }));
      s.add(m);
      renderer.setRenderTarget(target);
      renderer.render(s, c);
      renderer.setRenderTarget(null);
      m.geometry.dispose(); m.material.dispose();
      return target.texture;
    }
    const skyTex = bake(SKY_BAKE, Q.sky, Q.sky / 2);
    const surfaceTex = bake(SURFACE_BAKE, Q.planet, Q.planet / 2);
    const dataTex = bake(DATA_BAKE, Q.planet, Q.planet / 2);

    /* ---------- nebula sky ---------- */
    const sky = new THREE.Mesh(
      new THREE.SphereBufferGeometry(2500, 48, 32),
      new THREE.ShaderMaterial({
        side: THREE.BackSide, depthWrite: false,
        uniforms: { uMap: { value: skyTex }, uGain: { value: 1.15 } },
        vertexShader: 'varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
        fragmentShader: `
          uniform sampler2D uMap; uniform float uGain; varying vec3 vDir;
          float rnd(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
          void main(){
            vec3 d = normalize(vDir);
            vec2 uv = vec2(atan(d.z, d.x) / 6.2831853 + 0.5, acos(clamp(-d.y, -1.0, 1.0)) / 3.1415926);
            uv.x -= 0.5;
            vec3 c = texture2D(uMap, uv).rgb; c *= c;
            c = c * uGain + (rnd(gl_FragCoord.xy) - 0.5) / 255.0;   // dither: no banding in dark areas
            gl_FragColor = vec4(c, 1.0);
          }`
      })
    );
    scene.add(sky);

    /* ---------- background stars ---------- */
    const STAR_COLORS = [[0.65,0.75,1.0],[0.8,0.87,1.0],[1,1,1],[1,0.95,0.85],[1,0.84,0.62],[1,0.68,0.45]];
    const starsGeo = new THREE.BufferGeometry();
    {
      const n = Q.stars, pos = new Float32Array(n * 3), col = new Float32Array(n * 3), size = new Float32Array(n), phase = new Float32Array(n);
      for (let i = 0; i < n; i++) {
        const u = Math.random() * 2 - 1, t = Math.random() * Math.PI * 2, r = 500 + Math.random() * 1400, s = Math.sqrt(1 - u * u);
        pos[i*3] = r * s * Math.cos(t); pos[i*3+1] = r * u; pos[i*3+2] = r * s * Math.sin(t);
        const c = STAR_COLORS[Math.floor(Math.random() * STAR_COLORS.length)];
        col[i*3] = c[0]; col[i*3+1] = c[1]; col[i*3+2] = c[2];
        size[i] = 0.9 + Math.pow(Math.random(), 7.0) * 4.6;      // few bright stars, many faint
        phase[i] = Math.random() * Math.PI * 2;
      }
      starsGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      starsGeo.setAttribute('aColor', new THREE.BufferAttribute(col, 3));
      starsGeo.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
      starsGeo.setAttribute('aPhase', new THREE.BufferAttribute(phase, 1));
    }
    const starsMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uTime: { value: 0 }, uPR: { value: pixelRatio } },
      vertexShader: `
        attribute vec3 aColor; attribute float aSize, aPhase; uniform float uTime, uPR; varying vec3 vC; varying float vA;
        void main(){
          vC = aColor;
          vA = 0.62 + 0.38 * sin(uTime * (0.5 + aPhase * 0.28) + aPhase * 7.0);
          gl_PointSize = aSize * uPR * 1.6;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }`,
      fragmentShader: `
        varying vec3 vC; varying float vA;
        void main(){
          vec2 p = gl_PointCoord - 0.5; float d = length(p);
          float core = exp(-d * d * 42.0), halo = exp(-d * 7.5) * 0.28;
          gl_FragColor = vec4(vC, (core + halo) * vA * smoothstep(0.5, 0.36, d));
        }`
    });
    const stars = new THREE.Points(starsGeo, starsMat);
    stars.frustumCulled = false;
    scene.add(stars);

    /* ---------- spiral galaxy ---------- */
    const gauss = () => { let u = 0, v = 0; while (!u) u = Math.random(); while (!v) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(6.2831853 * v); };
    const GAL_R = 78, ARMS = 4;
    const GX = 40, GY = 28, GZ = -130;      // galaxy position: upper right, away from the hero text
    const galGeo = new THREE.BufferGeometry();
    {
      const gasCount = lowEnd ? 900 : 2600;
      const n = Q.galaxy + gasCount, pos = new Float32Array(n * 3), col = new Float32Array(n * 3), size = new Float32Array(n), rad = new Float32Array(n), alpha = new Float32Array(n);
      const core = new THREE.Color(1.0, 0.86, 0.66), mid = new THREE.Color(1.0, 0.50, 0.24), outer = new THREE.Color(0.38, 0.62, 1.0), c = new THREE.Color();
      for (let i = 0; i < n; i++) {
        const gas = i >= Q.galaxy;          // large, faint glowing clouds along the arms
        const bulge = !gas && Math.random() < 0.2;
        const r = bulge ? Math.abs(gauss()) * 9 : Math.pow(Math.random(), 1.45) * GAL_R;
        const arm = (i % ARMS) / ARMS * Math.PI * 2;
        const twist = Math.log(1 + r * 0.42) * 1.95;
        const spread = bulge ? 6.2831853 * Math.random() : gauss() * (0.2 + 0.32 * Math.exp(-r / 28));
        const a = arm + twist + spread;
        const jitter = 0.6 + r * 0.035;
        pos[i*3]   = Math.cos(a) * r + gauss() * jitter;
        pos[i*3+1] = gauss() * (bulge ? 3.4 * Math.exp(-r / 9) + 0.5 : 0.35 + 1.5 * Math.exp(-r / 16));
        pos[i*3+2] = Math.sin(a) * r + gauss() * jitter;
        const t = Math.min(r / GAL_R, 1);
        c.copy(core).lerp(mid, Math.min(t * 3.0, 1)).lerp(outer, Math.max(0, (t - 0.25) / 0.75));
        if (Math.random() < 0.012 && !bulge) c.setRGB(1.0, 0.36, 0.55);      // pink star-forming regions
        const v = 0.72 + Math.random() * 0.45;
        col[i*3] = c.r * v; col[i*3+1] = c.g * v; col[i*3+2] = c.b * v;
        size[i] = gas ? 12 + Math.random() * 22 : (0.55 + Math.random() * 1.0) * (Math.random() < 0.012 ? 3.0 : 1.0);
        alpha[i] = gas ? 0.06 + Math.random() * 0.06 : 0.72;
        rad[i] = r;
      }
      galGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      galGeo.setAttribute('aColor', new THREE.BufferAttribute(col, 3));
      galGeo.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
      galGeo.setAttribute('aRad', new THREE.BufferAttribute(rad, 1));
      galGeo.setAttribute('aAlpha', new THREE.BufferAttribute(alpha, 1));
    }
    const galMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uTime: { value: 0 }, uScale: { value: 300 }, uGain: { value: 1 } },
      vertexShader: `
        attribute vec3 aColor; attribute float aSize, aRad, aAlpha; uniform float uTime, uScale; varying vec3 vC; varying float vA;
        void main(){
          float a = uTime * 0.012 * (1.0 + 18.0 / (aRad + 9.0));   // inner stars orbit faster
          float s = sin(a), c = cos(a);
          vec3 p = vec3(position.x * c - position.z * s, position.y, position.x * s + position.z * c);
          vC = aColor; vA = aAlpha;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_PointSize = clamp(aSize * uScale / -mv.z, 1.2, 160.0);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        varying vec3 vC; varying float vA; uniform float uGain;
        void main(){
          float d = length(gl_PointCoord - 0.5);
          float a = exp(-d * d * 20.0) * smoothstep(0.5, 0.3, d);
          gl_FragColor = vec4(vC * uGain, a * vA);
        }`
    });
    const galaxy = new THREE.Group();
    const galPoints = new THREE.Points(galGeo, galMat);
    galPoints.frustumCulled = false;
    galaxy.add(galPoints);

    // Soft glowing core
    function glowTexture(stops){
      const c = document.createElement('canvas'); c.width = c.height = 256;
      const g = c.getContext('2d'), grd = g.createRadialGradient(128, 128, 0, 128, 128, 128);
      stops.forEach(s => grd.addColorStop(s[0], s[1]));
      g.fillStyle = grd; g.fillRect(0, 0, 256, 256);
      return new THREE.CanvasTexture(c);
    }
    const coreGlow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowTexture([[0,'rgba(255,236,205,0.95)'],[0.14,'rgba(255,190,125,0.55)'],[0.42,'rgba(255,110,50,0.14)'],[1,'rgba(255,90,31,0)']]),
      blending: THREE.AdditiveBlending, depthWrite: false, transparent: true
    }));
    coreGlow.scale.set(58, 58, 1);
    galaxy.add(coreGlow);
    galaxy.position.set(GX, GY, GZ);
    galaxy.rotation.set(1.02, 0.25, -0.38);
    scene.add(galaxy);

    /* ---------- planet ---------- */
    const SUN = new THREE.Vector3(-0.86, 0.36, 0.3).normalize();
    const planet = new THREE.Group();
    const PLANET_R = 9.5;
    const surface = new THREE.Mesh(
      new THREE.SphereBufferGeometry(PLANET_R, Q.seg, Q.seg * 0.75),
      new THREE.ShaderMaterial({
        uniforms: { uMap: { value: surfaceTex }, uData: { value: dataTex }, uSun: { value: SUN }, uTime: { value: 0 } },
        vertexShader: `
          varying vec2 vUv; varying vec3 vN, vW;
          void main(){
            vUv = uv;
            vN = normalize(mat3(modelMatrix) * normal);
            vec4 w = modelMatrix * vec4(position, 1.0);
            vW = w.xyz;
            gl_Position = projectionMatrix * viewMatrix * w;
          }`,
        fragmentShader: `
          uniform sampler2D uMap, uData; uniform vec3 uSun; uniform float uTime;
          varying vec2 vUv; varying vec3 vN, vW;
          float data_ocean(float h){ return 1.0 - smoothstep(0.49, 0.52, h); }
          vec3 aces(vec3 x){ return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }
          void main(){
            vec3 n = normalize(vN), v = normalize(cameraPosition - vW);
            vec4 sm = texture2D(uMap, vUv);
            vec3 albedo = sm.rgb * sm.rgb;
            float relief = (sm.a - texture2D(uMap, vUv + vec2(0.0016, 0.0012)).a) * 26.0 * (1.0 - data_ocean(sm.a));
            vec3 data = texture2D(uData, vUv).rgb;
            vec2 cuv = vUv + vec2(uTime * 0.0016, 0.0);
            float clouds = texture2D(uData, cuv).r;
            float shadow = texture2D(uData, cuv + vec2(0.0025, 0.0012)).r;

            float ndl = dot(n, uSun);
            float day = smoothstep(-0.05, 0.28, ndl);
            float diff = max(ndl, 0.0);
            vec3 sunCol = vec3(1.0, 0.96, 0.9) * 2.5;

            vec3 col = albedo * sunCol * diff * (1.0 + relief) * (1.0 - shadow * 0.55);
            vec3 h = normalize(uSun + v);
            col += vec3(1.0, 0.86, 0.66) * pow(max(dot(n, h), 0.0), 220.0) * data.b * (1.0 - clouds) * 0.2 * day;   // sun glint on oceans
            col = mix(col, vec3(0.82) * sunCol * (diff * 0.9 + 0.012), clouds * 0.9);

            // terminator warmth and city lights on the night side
            col += vec3(1.0, 0.36, 0.1) * clouds * 0.12 * smoothstep(0.26, 0.0, abs(ndl));
            col += vec3(1.0, 0.62, 0.28) * data.g * 1.9 * (1.0 - day) * (1.0 - clouds * 0.85);

            // atmosphere seen through the limb
            float fres = pow(1.0 - max(dot(n, v), 0.0), 3.2);
            vec3 atm = mix(vec3(0.20, 0.50, 1.0), vec3(1.0, 0.45, 0.2), smoothstep(0.45, 0.0, ndl));
            col += atm * fres * smoothstep(-0.25, 0.3, ndl) * 1.15;
            gl_FragColor = vec4(aces(col), 1.0);
          }`
      })
    );
    const atmosphere = new THREE.Mesh(
      new THREE.SphereBufferGeometry(PLANET_R * 1.055, Q.seg, Q.seg * 0.75),
      new THREE.ShaderMaterial({
        side: THREE.BackSide, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
        uniforms: { uSun: { value: SUN } },
        vertexShader: `
          varying vec3 vN, vW;
          void main(){
            vN = normalize(mat3(modelMatrix) * normal);
            vec4 w = modelMatrix * vec4(position, 1.0);
            vW = w.xyz;
            gl_Position = projectionMatrix * viewMatrix * w;
          }`,
        fragmentShader: `
          uniform vec3 uSun; varying vec3 vN, vW;
          void main(){
            vec3 n = normalize(vN), v = normalize(cameraPosition - vW);
            float k = clamp(-dot(n, v) / 0.32, 0.0, 1.0);
            float sun = smoothstep(-0.35, 0.5, dot(n, uSun));
            vec3 col = mix(vec3(1.0, 0.42, 0.16), vec3(0.28, 0.58, 1.0), smoothstep(0.0, 0.55, dot(n, uSun)));
            gl_FragColor = vec4(col, pow(k, 2.3) * sun * 0.95);
          }`
      })
    );
    planet.add(surface, atmosphere);
    planet.rotation.z = 0.36;
    scene.add(planet);

    /* ---------- shooting stars ---------- */
    const meteorGeo = new THREE.BufferGeometry();
    meteorGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(6), 3));
    meteorGeo.setAttribute('color', new THREE.BufferAttribute(new Float32Array([1, 0.92, 0.82, 0, 0, 0]), 3));
    const meteorMat = new THREE.LineBasicMaterial({ vertexColors: true, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, opacity: 0 });
    const meteor = new THREE.Line(meteorGeo, meteorMat);
    meteor.frustumCulled = false;
    camera.add(meteor);
    function shootStar(){
      if (document.hidden) return gsap.delayedCall(6, shootStar);
      const aspect = camera.aspect, hh = Math.tan(camera.fov * Math.PI / 360) * 100, hw = hh * aspect;
      const x0 = (Math.random() * 1.6 - 0.8) * hw, y0 = (0.15 + Math.random() * 0.75) * hh;
      const ang = -0.35 - Math.random() * 0.5, dir = Math.random() < 0.5 ? 1 : -1;
      const dx = Math.cos(ang) * dir, dy = Math.sin(ang), len = hh * (0.25 + Math.random() * 0.3), travel = hh * (0.8 + Math.random() * 0.7);
      const m = { t: 0 }, p = meteorGeo.attributes.position;
      gsap.timeline({ onComplete: () => gsap.delayedCall(7 + Math.random() * 12, shootStar) })
        .to(meteorMat, { opacity: 0.85, duration: 0.14, ease: 'none' }, 0)
        .to(m, { t: 1, duration: 0.85, ease: 'power1.in', onUpdate(){
          const hx = x0 + dx * travel * m.t, hy = y0 + dy * travel * m.t, tail = len * Math.min(m.t * 4, 1);
          p.setXYZ(0, hx, hy, -100); p.setXYZ(1, hx - dx * tail, hy - dy * tail, -100); p.needsUpdate = true;
        } }, 0)
        .to(meteorMat, { opacity: 0, duration: 0.26, ease: 'none' }, 0.62);
    }

    /* ---------- camera path, driven by scroll ---------- */
    const S = {
      x: 0, y: 2, z: 34, tx: 0, ty: 0, tz: 0,                    // camera position and look target
      px: 19, py: -8.5, pz: 2,                                   // planet
      gain: 0.85,                                                // galaxy brightness
      intro: 0, mx: 0, my: 0,                                    // intro dolly and mouse parallax
      fly: 0                                                     // dragon flight: 0 at page top, 1 at page bottom
    };
    let dragon = null, front = null;
    const firstVisit = (() => {
      try { const seen = sessionStorage.getItem('bg3dSeen'); sessionStorage.setItem('bg3dSeen', '1'); return !seen; }
      catch (e) { return false; }
    })();

    function resize(){
      const w = canvas.clientWidth || window.innerWidth, h = canvas.clientHeight || window.innerHeight;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      // On narrow screens pull the camera back a little so the planet still fits.
      camera.fov = camera.aspect < 1 ? 62 : 50;
      camera.updateProjectionMatrix();
      galMat.uniforms.uScale.value = h * pixelRatio * 0.25;
      starsMat.uniforms.uPR.value = pixelRatio;
      if (dragon) dragon.layout();
      if (front) { front.setPixelRatio(pixelRatio); front.setSize(w, h, false); }
    }
    resize();
    if (window.createDragon) dragon = window.createDragon(THREE, camera, { low: lowEnd });

    // Second, transparent canvas above the page content (below the nav): the parts of
    // the dragon flying "over" the cards are drawn here. Clicks pass straight through.
    // Small screens skip it: there the dragon would hide headings and text.
    if (dragon && window.innerWidth > 820) {
      try {
        const fc = document.createElement('canvas');
        fc.setAttribute('aria-hidden', 'true');
        fc.style.cssText = 'position:fixed;top:0;left:0;z-index:30;pointer-events:none;opacity:0;width:100%;height:' + canvas.style.height + ';';
        document.body.appendChild(fc);
        front = new THREE.WebGLRenderer({ canvas: fc, antialias: true, alpha: true, powerPreference: 'high-performance', stencil: false });
        front.setClearColor(0x000000, 0);
        resize();
      } catch (e) { front = null; }   // the dragon then simply stays behind the content
    }

    function fadeIn(sec){
      [canvas, front && front.domElement].forEach(c => { if (c) { c.style.transition = 'opacity ' + sec + 's ease-out'; c.style.opacity = '1'; } });
    }

    const clock = new THREE.Clock();
    let lastTime = 0, lastFly = 0, flap = 0, flown = 0;
    function draw(){
      const t = clock.getElapsedTime();
      const dt = Math.max(t - lastTime, 0.001); lastTime = t;
      // Fast scrolling makes the dragon beat harder; it calms down when scrolling stops.
      const moved = Math.abs(S.fly - lastFly); lastFly = S.fly;
      const speed = Math.min(moved / dt * 14, 1);
      flown += moved;   // scrolling either way adds distance, so the dragon never flies tail-first
      flap += (speed - flap) * Math.min(dt * 3.5, 1);
      starsMat.uniforms.uTime.value = t;
      galMat.uniforms.uTime.value = t;
      galMat.uniforms.uGain.value = S.gain;
      coreGlow.material.opacity = 0.6 * S.gain;
      surface.material.uniforms.uTime.value = t;
      surface.rotation.y = t * 0.022;
      stars.rotation.y = t * 0.0022;
      sky.rotation.y = t * 0.0009;

      const narrow = Math.min(1, camera.aspect / 1.6);
      planet.position.set(S.px * Math.max(0.3, narrow), S.py - (1 - narrow) * 11, S.pz);   // lower on phones, clear of the text

      camera.position.set(S.x + S.mx * 1.5, S.y + S.my * 1.0, S.z + S.intro);
      camera.lookAt(S.tx + S.mx * 0.5, S.ty + S.my * 0.35, S.tz);
      if (dragon) dragon.update(t, flown * dragon.loopLength * DRAGON_LAPS, S.mx, S.my, flap, SUN);
      if (dragon) dragon.setPass(front ? 0 : 2);
      camera.layers.enable(1);
      renderer.render(scene, camera);
      if (front) {
        dragon.setPass(1);
        camera.layers.set(1);
        front.render(scene, camera);
        camera.layers.set(0);
      }
    }

    if (reduceMotion) {
      // Still scene: no scroll flight, no twinkle, no intro.
      draw();
      fadeIn(0.4);
      let rt;
      window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => { resize(); draw(); }, 150); });
      return;
    }

    gsap.timeline({ scrollTrigger: { start: 0, end: 'max', scrub: 1.3, invalidateOnRefresh: true }, defaults: { ease: 'none' } })
      // the dragon flies along with the scroll, for the whole page
      .to(S, { fly: 1, duration: 1 }, 0)
      // leave the planet behind
      .to(S, { x: 12, y: 8, z: 6, tx: 24, ty: 14, tz: -70, px: 34, py: -28, pz: -4, duration: 0.34, ease: 'sine.inOut' }, 0)
      // travel towards the galaxy
      .to(S, { x: 24, y: 17, z: -30, tx: GX, ty: GY, tz: GZ, duration: 0.36, ease: 'sine.inOut' }, 0.34)
      // glide in towards the bright core
      .to(S, { x: 30, y: 22, z: -58, tx: GX, ty: GY, tz: GZ, gain: 0.5, duration: 0.30, ease: 'sine.inOut' }, 0.70);

    // Mouse parallax (pointer devices only)
    if (matchMedia('(hover: hover)').matches) {
      const qx = gsap.quickTo(S, 'mx', { duration: 1.4, ease: 'power3.out' });
      const qy = gsap.quickTo(S, 'my', { duration: 1.4, ease: 'power3.out' });
      window.addEventListener('pointermove', e => { qx(e.clientX / window.innerWidth * 2 - 1); qy(1 - e.clientY / window.innerHeight * 2); }, { passive: true });
    }

    // Intro: long camera glide on the first page of a visit, a quick fade after that.
    if (firstVisit) {
      S.intro = 26;
      gsap.to(S, { intro: 0, duration: 3.2, ease: 'expo.out' });
      fadeIn(1.6);
    } else {
      fadeIn(0.5);
    }

    // Render with GSAP's ticker. It sleeps while the tab is in the background.
    // If the device struggles, drop render resolution so scrolling stays smooth.
    let frames = 0, slow = 0, lastT = performance.now();
    gsap.ticker.add(() => {
      draw();
      const now = performance.now(), dt = now - lastT; lastT = now;
      if (dt < 200 && ++frames > 40) {
        slow = slow * 0.95 + (dt > 30 ? 0.05 : 0);
        if (slow > 0.6 && pixelRatio > 0.8) {
          pixelRatio = Math.max(0.8, pixelRatio - 0.25);
          renderer.setPixelRatio(pixelRatio);
          resize();
          slow = 0; frames = 0;
        }
      }
    });

    // Ignore the mobile address-bar show/hide so the scene doesn't jump.
    let lastW = window.innerWidth, lastH = window.innerHeight, rt;
    window.addEventListener('resize', () => {
      clearTimeout(rt);
      rt = setTimeout(() => {
        const dw = Math.abs(window.innerWidth - lastW), dh = Math.abs(window.innerHeight - lastH);
        if (dw > 0 || dh > 140) { lastW = window.innerWidth; lastH = window.innerHeight; resize(); window.ScrollTrigger.refresh(); }
      }, 150);
    });
    window.addEventListener('load', () => window.ScrollTrigger.refresh());
    canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); gsap.ticker.sleep(); fail('context lost'); });

    if (SHOOTING_STARS) gsap.delayedCall(4 + Math.random() * 5, shootStar);
  }

  // Start after the page itself has loaded, so the content always comes first.
  if (document.readyState === 'complete') start();
  else window.addEventListener('load', start);
})();
