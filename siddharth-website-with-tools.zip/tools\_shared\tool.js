/* =====================================================================
   SDM TOOLS — shared script for every tool page (tools/<tool>/index.html)
   - Adds the site nav, mobile menu and footer (same as the main site)
   - Starfield background, FAQ toggles, related-tool links
   - Small helpers on window.SDM: copy, download, toast, esc, textWidth
   Tool pages live two folders deep, so site links start with ../../
   ===================================================================== */
(function(){
  'use strict';
  const ROOT = '../../';

  /* Live tools — used for the "Related tools" block. Add new tools here
     (and set status:'live' + url in tools/index.html). */
  const LIVE_TOOLS = [
    { id:'word-counter',              name:'Word Counter',              desc:'Words, characters, sentences and reading time.', cat:'utilities' },
    { id:'character-counter',         name:'Character Counter',         desc:'Characters with and without spaces, SEO limits.', cat:'utilities' },
    { id:'url-slug-generator',        name:'URL Slug Generator',        desc:'Clean, SEO-friendly URL slugs.', cat:'utilities' },
    { id:'url-encoder-decoder',       name:'URL Encoder & Decoder',     desc:'Encode or decode text and full URLs.', cat:'utilities' },
    { id:'robots-txt-generator',      name:'Robots.txt Generator',      desc:'Build robots.txt with presets and AI-bot rules.', cat:'utilities' },
    { id:'xml-sitemap-generator',     name:'XML Sitemap Generator',     desc:'Turn a URL list into a sitemap.xml.', cat:'utilities' },
    { id:'serp-snippet-preview',      name:'SERP Snippet Preview',      desc:'See how your page looks on Google.', cat:'utilities' },
    { id:'utm-url-builder',           name:'UTM URL Builder',           desc:'Campaign URLs with UTM parameters.', cat:'utilities' },
    { id:'regular-expression-tester', name:'Regular Expression Tester', desc:'Test JavaScript regex with highlights.', cat:'utilities' },
    { id:'title-tag-checker',         name:'Title Tag Checker',         desc:'Title length, pixel width and checks.', cat:'audit' },
    { id:'meta-description-checker',  name:'Meta Description Checker',  desc:'Description length, pixel width and checks.', cat:'audit' }
  ];

  const NAV_LINKS = [
    ['index.html#home','Home'],['services.html','Services'],['projects.html','Project'],
    ['portfolio.html','Portfolio'],['about.html','About us'],['blog.html','Blog'],
    ['tools/','SDM Tools'],['contact.html','Contact us']
  ];
  // Same social icons as the main site's mobile menu
  const SOCIALS =
    '<a href="#" aria-label="Facebook" style="background:#1877F2;border-color:#1877F2;"><svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c5.05-.5 9-4.76 9-9.95z"/></svg></a>' +
    '<a href="#" aria-label="Instagram" style="background:linear-gradient(45deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888);border-color:transparent;"><svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><path d="M12 2c2.72 0 3.06.01 4.12.06 1.06.05 1.79.22 2.43.47.66.26 1.22.6 1.77 1.15.55.55.9 1.11 1.15 1.77.25.64.42 1.37.47 2.43.05 1.06.06 1.4.06 4.12s-.01 3.06-.06 4.12c-.05 1.06-.22 1.79-.47 2.43-.26.66-.6 1.22-1.15 1.77-.55.55-1.11.9-1.77 1.15-.64.25-1.37.42-2.43.47-1.06.05-1.4.06-4.12.06s-3.06-.01-4.12-.06c-1.06-.05-1.79-.22-2.43-.47-.66-.26-1.22-.6-1.77-1.15-.55-.55-.9-1.11-1.15-1.77-.25-.64-.42-1.37-.47-2.43C2.01 15.06 2 14.72 2 12s.01-3.06.06-4.12c.05-1.06.22-1.79.47-2.43.26-.66.6-1.22 1.15-1.77.55-.55 1.11-.9 1.77-1.15.64-.25 1.37-.42 2.43-.47C8.94 2.01 9.28 2 12 2zm0 1.8c-2.67 0-2.99.01-4.04.06-.86.04-1.32.18-1.63.3-.41.16-.7.35-1.01.66-.31.31-.5.6-.66 1.01-.12.31-.26.77-.3 1.63C4.31 9.01 4.3 9.33 4.3 12s.01 2.99.06 4.04c.04.86.18 1.32.3 1.63.16.41.35.7.66 1.01.31.31.6.5 1.01.66.31.12.77.26 1.63.3 1.05.05 1.37.06 4.04.06s2.99-.01 4.04-.06c.86-.04 1.32-.18 1.63-.3.41-.16.7-.35 1.01-.66.31-.31.5-.6.66-1.01.12-.31.26-.77.3-1.63.05-1.05.06-1.37.06-4.04s-.01-2.99-.06-4.04c-.04-.86-.18-1.32-.3-1.63-.16-.41-.35-.7-.66-1.01-.31-.31-.6-.5-1.01-.66-.31-.12-.77-.26-1.63-.3C14.99 3.81 14.67 3.8 12 3.8zm0 3.05a5.15 5.15 0 110 10.3 5.15 5.15 0 010-10.3zm0 8.5a3.35 3.35 0 100-6.7 3.35 3.35 0 000 6.7zm6.55-8.7a1.2 1.2 0 11-2.4 0 1.2 1.2 0 012.4 0z"/></svg></a>' +
    '<a href="#" aria-label="LinkedIn" style="background:#0A66C2;border-color:#0A66C2;"><svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><path d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.03-1.85-3.03-1.85 0-2.14 1.44-2.14 2.94v5.66H9.34V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.38-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.07 2.07 0 110-4.14 2.07 2.07 0 010 4.14zM7.12 20.45H3.55V9h3.57v11.45z"/></svg></a>';

  const navHTML = NAV_LINKS.map(([h,t]) =>
    '<a href="' + ROOT + h + '"' + (t === 'SDM Tools' ? ' style="color:var(--gold);"' : '') + '>' + t + '</a>').join('');

  function chrome(){
    const body = document.body;
    const top = document.createElement('div');
    top.innerHTML =
      '<canvas id="stars"></canvas>' +
      '<nav><div class="nav-left"><button class="nav-toggle" id="navToggle" aria-label="Menu">☰</button>' +
      '<a class="logo" href="' + ROOT + 'index.html#home">Siddharth<span>.</span></a></div>' +
      '<div class="nav-links">' + navHTML + '</div>' +
      '<div class="nav-right"><a href="' + ROOT + 'contact.html" class="cta-btn">Let\'s Talk</a></div></nav>' +
      '<div class="mobile-menu" id="mobileMenu"><div class="mobile-top"><div class="logo">Siddharth<span>.</span></div>' +
      '<button class="mobile-close" id="mobileClose" aria-label="Close">✕</button></div>' +
      '<div class="mobile-links">' + navHTML + '</div>' +
      '<div class="mobile-contact"><a href="mailto:siddharthchoudhary654@gmail.com">siddharthchoudhary654@gmail.com</a>' +
      '<a href="tel:+919523862428">+91-9523862428</a></div>' +
      '<a href="' + ROOT + 'contact.html" class="mobile-cta">Let\'s Talk</a>' +
      '<div class="mobile-socials">' + SOCIALS + '</div></div>' +
      '<div class="mobile-overlay" id="mobileOverlay"></div>';
    const frag = document.createDocumentFragment();
    while (top.firstChild) frag.appendChild(top.firstChild);
    body.insertBefore(frag, body.firstChild);

    const foot = document.createElement('footer');
    foot.innerHTML =
      '<div class="footer-grid">' +
        '<div class="footer-col"><div class="logo" style="margin-bottom:14px;">Siddharth<span>.</span></div>' +
        '<p>Helping startups, agencies, healthcare, and eCommerce brands grow with websites, SEO, and AI-powered creative solutions.</p></div>' +
        '<div class="footer-col"><h4>Quick Links</h4><ul>' +
          '<li><a href="' + ROOT + 'index.html#home">Home</a></li><li><a href="' + ROOT + 'about.html">About us</a></li>' +
          '<li><a href="' + ROOT + 'tools/">SDM Tools</a></li><li><a href="' + ROOT + 'contact.html">Contact us</a></li></ul></div>' +
        '<div class="footer-col"><h4>Services</h4><ul>' +
          '<li><a href="' + ROOT + 'services.html#svc-wordpress">WordPress Development</a></li><li><a href="' + ROOT + 'services.html#svc-seo">SEO</a></li>' +
          '<li><a href="' + ROOT + 'services.html#svc-ai">AI Creative Solutions</a></li><li><a href="' + ROOT + 'services.html#svc-ecom">eCommerce Development</a></li></ul></div>' +
        '<div class="footer-col"><h4>Contact</h4><ul>' +
          '<li><a href="mailto:siddharthchoudhary654@gmail.com">siddharthchoudhary654@gmail.com</a></li>' +
          '<li><a href="tel:+919523862428">+91-9523862428</a></li></ul></div>' +
      '</div>' +
      '<div class="footer-bottom"><div>© 2026 Siddharth Choudhary Digital Marketing. All rights reserved.</div><div class="footer-socials">' + SOCIALS + '</div></div>';
    body.appendChild(foot);

    const toast = document.createElement('div');
    toast.className = 'toast'; toast.id = 'sdmToast';
    body.appendChild(toast);

    // mobile menu
    const menu = document.getElementById('mobileMenu'), overlay = document.getElementById('mobileOverlay');
    const open = () => { menu.classList.add('open'); overlay.classList.add('open'); };
    const close = () => { menu.classList.remove('open'); overlay.classList.remove('open'); };
    document.getElementById('navToggle').addEventListener('click', open);
    document.getElementById('mobileClose').addEventListener('click', close);
    overlay.addEventListener('click', close);
  }

  function stars(){
    const canvas = document.getElementById('stars');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let w, h, list = [];
    function resize(){
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
      list = [];
      const count = Math.floor((w*h)/9000);
      for (let i=0;i<count;i++) list.push({x:Math.random()*w,y:Math.random()*h,r:Math.random()*1.3+0.2,a:Math.random(),s:Math.random()*0.015});
    }
    function draw(){
      ctx.fillStyle = '#07070b'; ctx.fillRect(0,0,w,h);
      list.forEach(st => {
        st.a += st.s;
        const op = (Math.sin(st.a)+1)/2*0.8+0.2;
        ctx.beginPath(); ctx.arc(st.x,st.y,st.r,0,Math.PI*2);
        ctx.fillStyle = 'rgba(212,175,55,' + (op*0.6) + ')'; ctx.fill();
      });
      requestAnimationFrame(draw);
    }
    window.addEventListener('resize', resize);
    resize(); draw();
  }

  function faq(){
    document.querySelectorAll('.faq-item').forEach(item => {
      item.addEventListener('click', () => {
        const isOpen = item.classList.contains('open');
        document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
        if (!isOpen) item.classList.add('open');
      });
    });
  }

  function related(){
    const box = document.getElementById('relatedTools');
    if (!box) return;
    const current = box.dataset.current, cat = box.dataset.cat;
    const others = LIVE_TOOLS.filter(t => t.id !== current);
    others.sort((a,b) => (b.cat === cat) - (a.cat === cat));
    box.innerHTML = others.slice(0, 6).map(t =>
      '<a href="../' + t.id + '/">' + esc(t.name) + '<small>' + esc(t.desc) + '</small></a>').join('');
  }

  /* ---------- helpers ---------- */
  function esc(s){
    return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }
  let toastTimer;
  function toast(msg){
    const t = document.getElementById('sdmToast');
    if (!t) return;
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 1800);
  }
  function copy(text, msg){
    const done = () => toast(msg || 'Copied!');
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done, () => fallback());
    } else fallback();
    function fallback(){
      const ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); done(); } catch(e) { toast('Copy failed — select and copy manually'); }
      ta.remove();
    }
  }
  function download(filename, text, mime){
    const blob = new Blob([text], { type: (mime || 'text/plain') + ';charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    toast('Downloaded ' + filename);
  }
  /* Rendered width of text in px (estimate of how Google measures snippets). */
  const measureCtx = document.createElement('canvas').getContext('2d');
  function textWidth(text, font){
    measureCtx.font = font || '20px Arial';
    return Math.round(measureCtx.measureText(text).width);
  }
  /* Cut text so it fits maxPx, adding an ellipsis the way Google does. */
  function truncateToWidth(text, maxPx, font){
    if (textWidth(text, font) <= maxPx) return { text, cut:false };
    let lo = 0, hi = text.length;
    while (lo < hi) {
      const mid = Math.ceil((lo+hi)/2);
      if (textWidth(text.slice(0,mid).trimEnd() + ' ...', font) <= maxPx) lo = mid; else hi = mid - 1;
    }
    let cut = text.slice(0, lo);
    const sp = cut.lastIndexOf(' ');
    if (sp > lo * 0.6) cut = cut.slice(0, sp);
    return { text: cut.trimEnd() + ' ...', cut:true };
  }

  window.SDM = { esc, toast, copy, download, textWidth, truncateToWidth };

  function init(){ chrome(); stars(); faq(); related(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
